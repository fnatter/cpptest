//============================================================================
// Name        : cpptest1.cpp
// Author      : Felix Natter
// Version     :
// Copyright   : GPL-3+...
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <memory>
#include <sstream>
#include "RationalNumber.h"

using namespace std;

enum Operator { plus, minus, multiply, divide };

int main(int argc, char** argv)
{
	if (argc != 3)
	{
		cout << "Syntax: <rational> <operator> <rational>" << endl;
		return 1;
	}

	istringstream input;

	RationalNumber r1;
	input.str(argv[1]);
	input >> r1;

	Operator op;
	string opString = string(argv[2]);
	if (opString == "+" || opString == "plus")
	{
		op = plus;
	}
	else if (opString == "-" || opString == "minus")
	{
		op = minus;
	}
	else if (opString == "*" || opString == "multiply")
	{
		op = multiply;
	}
	else if (opString == "/" || opString == "divide")
	{
		op = divide;
	}

	RationalNumber r2;
	input.str(argv[3]);
	input >> r2;

	cout << r1 << " " << opString << " " << r2 << " = ";



	return 0;
}
